import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { ProductsComponent } from './pages/products/products.component';
import { PropertiesComponent } from './pages/properties/properties.component';
import { PartnerComponent } from './pages/partner/partner.component';
import { ContactComponent } from './pages/contact/contact.component';
import { HeaderComponent } from './theme/header/header.component';
import { FooterComponent } from './theme/footer/footer.component';

import { AppserviceService } from '../app/services/appservice.service';

const appRoutes  = [
  
  {
    path: '',
    redirectTo:'/home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'product',
    component: ProductsComponent
  },
  {
    path: 'properties',
    component: PropertiesComponent
  },
  {
    path: 'partner',
    component: PartnerComponent
  },
  {
    path: 'contact',
    component: ContactComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProductsComponent,
    PropertiesComponent,
    HeaderComponent,
    FooterComponent,
    PartnerComponent,
    ContactComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    HttpModule,
  ],
  providers: [AppserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
