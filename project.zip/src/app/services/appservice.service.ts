import { Injectable } from '@angular/core';
import {Http, Response, Headers,RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/observable';
import 'rxjs/add/operator/map';

@Injectable({
  providedIn: 'root'
})
export class AppserviceService {

  constructor(private http :Http) { }
  fetchNewsData() {
    return this.http.get("http://api.qapstrats.com/api/news").map((res:any)=>res.json());
  }
  fetchPropertiesData() {
    return this.http.get("http://api.qapstrats.com/api/properties").map((res:any)=>res.json());
  }
}
