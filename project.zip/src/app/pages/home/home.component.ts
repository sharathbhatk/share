import { Component, OnInit } from '@angular/core';
import { AppserviceService } from '../../services/appservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  news= [];
  newsObj: {};
  constructor(private _appservice: AppserviceService) { }

  loadData(){
    this._appservice.fetchNewsData().subscribe((data) => {
      this.newsObj = JSON.parse(data);
      this.news.push(this.newsObj[0]);
    })
  }
  ngOnInit() {
    this.loadData();
  }
}
