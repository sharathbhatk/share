import { Component, OnInit } from '@angular/core';
import { AppserviceService } from '../../services/appservice.service';

@Component({
  selector: 'app-properties',
  templateUrl: './properties.component.html',
  styleUrls: ['./properties.component.css']
})
export class PropertiesComponent implements OnInit {
products=[];
productsObj={};
  constructor(private _appservice: AppserviceService) { }
  loadData(): void {
    this._appservice.fetchNewsData().subscribe((data) => {
      this.productsObj = JSON.parse(data);
      this.products.push(this.productsObj[0]);
    })
  }
  ngOnInit() {
    this.loadData();
  }

}
